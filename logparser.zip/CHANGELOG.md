## [1.8.5](https://github.com/oclif/example-multi-js/compare/v1.8.4...v1.8.5) (2018-07-02)


### Bug Fixes

* oclif v1.8.6 ([100b5be](https://github.com/oclif/example-multi-js/commit/100b5be))

## [1.8.4](https://github.com/oclif/example-multi-js/compare/v1.8.3...v1.8.4) (2018-06-16)


### Bug Fixes

* oclif v1.8.5 ([0e3b6fd](https://github.com/oclif/example-multi-js/commit/0e3b6fd))

## [1.8.3](https://github.com/oclif/example-multi-js/compare/v1.8.2...v1.8.3) (2018-06-14)


### Bug Fixes

* oclif v1.8.3 ([273d7cb](https://github.com/oclif/example-multi-js/commit/273d7cb))
* oclif v1.8.4 ([7d9a4f3](https://github.com/oclif/example-multi-js/commit/7d9a4f3))

## [1.8.2](https://github.com/oclif/example-multi-js/compare/v1.8.1...v1.8.2) (2018-06-12)


### Bug Fixes

* oclif v1.8.2 ([3d47372](https://github.com/oclif/example-multi-js/commit/3d47372)), closes [#123](https://github.com/oclif/example-multi-js/issues/123)

## [1.8.1](https://github.com/oclif/example-multi-js/compare/v1.8.0...v1.8.1) (2018-06-10)


### Bug Fixes

* oclif v1.8.1 ([8c93c90](https://github.com/oclif/example-multi-js/commit/8c93c90))

<a name="1.8.0"></a>
# [1.8.0](https://github.com/oclif/example-multi-js/compare/v1.7.51...v1.8.0) (2018-06-02)


### Features

* oclif v1.8.0 ([842e6c0](https://github.com/oclif/example-multi-js/commit/842e6c0))

<a name="1.7.51"></a>
## [1.7.51](https://github.com/oclif/example-multi-js/compare/v1.7.50...v1.7.51) (2018-06-01)


### Bug Fixes

* oclif v1.7.56 ([27bea77](https://github.com/oclif/example-multi-js/commit/27bea77))

<a name="1.7.50"></a>
## [1.7.50](https://github.com/oclif/example-multi-js/compare/v1.7.49...v1.7.50) (2018-06-01)


### Bug Fixes

* oclif v1.7.55 ([280a998](https://github.com/oclif/example-multi-js/commit/280a998))

<a name="1.7.49"></a>
## [1.7.49](https://github.com/oclif/example-multi-js/compare/v1.7.48...v1.7.49) (2018-06-01)


### Bug Fixes

* oclif v1.7.54 ([17f780d](https://github.com/oclif/example-multi-js/commit/17f780d))

<a name="1.7.48"></a>
## [1.7.48](https://github.com/oclif/example-multi-js/compare/v1.7.47...v1.7.48) (2018-05-31)


### Bug Fixes

* oclif v1.7.53 ([a31e39b](https://github.com/oclif/example-multi-js/commit/a31e39b))

<a name="1.7.47"></a>
## [1.7.47](https://github.com/oclif/example-multi-js/compare/v1.7.46...v1.7.47) (2018-05-30)


### Bug Fixes

* oclif v1.7.52 ([7620850](https://github.com/oclif/example-multi-js/commit/7620850)), closes [#124](https://github.com/oclif/example-multi-js/issues/124)

<a name="1.7.46"></a>
## [1.7.46](https://github.com/oclif/example-multi-js/compare/v1.7.45...v1.7.46) (2018-05-28)


### Bug Fixes

* oclif v1.7.51 ([b290cc4](https://github.com/oclif/example-multi-js/commit/b290cc4))

<a name="1.7.45"></a>
## [1.7.45](https://github.com/oclif/example-multi-js/compare/v1.7.44...v1.7.45) (2018-05-24)


### Bug Fixes

* oclif v1.7.50 ([8faaa77](https://github.com/oclif/example-multi-js/commit/8faaa77))

<a name="1.7.44"></a>
## [1.7.44](https://github.com/oclif/example-multi-js/compare/v1.7.43...v1.7.44) (2018-05-22)


### Bug Fixes

* oclif v1.7.49 ([28e850a](https://github.com/oclif/example-multi-js/commit/28e850a))

<a name="1.7.43"></a>
## [1.7.43](https://github.com/oclif/example-multi-js/compare/v1.7.42...v1.7.43) (2018-05-22)


### Bug Fixes

* oclif v1.7.48 ([4118154](https://github.com/oclif/example-multi-js/commit/4118154))

<a name="1.7.42"></a>
## [1.7.42](https://github.com/oclif/example-multi-js/compare/v1.7.41...v1.7.42) (2018-05-22)


### Bug Fixes

* oclif v1.7.45 ([8da1eb4](https://github.com/oclif/example-multi-js/commit/8da1eb4))
* oclif v1.7.46 ([d0e5329](https://github.com/oclif/example-multi-js/commit/d0e5329))
* oclif v1.7.47 ([610f2e9](https://github.com/oclif/example-multi-js/commit/610f2e9))

<a name="1.7.41"></a>
## [1.7.41](https://github.com/oclif/example-multi-js/compare/v1.7.40...v1.7.41) (2018-05-11)


### Bug Fixes

* oclif v1.7.44 ([e284773](https://github.com/oclif/example-multi-js/commit/e284773))

<a name="1.7.40"></a>
## [1.7.40](https://github.com/oclif/example-multi-js/compare/v1.7.39...v1.7.40) (2018-05-11)


### Bug Fixes

* oclif v1.7.43 ([4ffef28](https://github.com/oclif/example-multi-js/commit/4ffef28))

<a name="1.7.39"></a>
## [1.7.39](https://github.com/oclif/example-multi-js/compare/v1.7.38...v1.7.39) (2018-05-10)


### Bug Fixes

* oclif v1.7.42 ([6c88c2a](https://github.com/oclif/example-multi-js/commit/6c88c2a))

<a name="1.7.38"></a>
## [1.7.38](https://github.com/oclif/example-multi-js/compare/v1.7.37...v1.7.38) (2018-05-10)


### Bug Fixes

* oclif v1.7.41 ([1acda58](https://github.com/oclif/example-multi-js/commit/1acda58))

<a name="1.7.37"></a>
## [1.7.37](https://github.com/oclif/example-multi-js/compare/v1.7.36...v1.7.37) (2018-05-07)


### Bug Fixes

* oclif v1.7.40 ([a430489](https://github.com/oclif/example-multi-js/commit/a430489))

<a name="1.7.36"></a>
## [1.7.36](https://github.com/oclif/example-multi-js/compare/v1.7.35...v1.7.36) (2018-05-07)


### Bug Fixes

* oclif v1.7.39 ([46799c9](https://github.com/oclif/example-multi-js/commit/46799c9))

<a name="1.7.35"></a>
## [1.7.35](https://github.com/oclif/example-multi-js/compare/v1.7.34...v1.7.35) (2018-05-04)


### Bug Fixes

* oclif v1.7.38 ([5ee9d22](https://github.com/oclif/example-multi-js/commit/5ee9d22))

<a name="1.7.34"></a>
## [1.7.34](https://github.com/oclif/example-multi-js/compare/v1.7.33...v1.7.34) (2018-05-03)


### Bug Fixes

* oclif v1.7.37 ([5a5bb76](https://github.com/oclif/example-multi-js/commit/5a5bb76))

<a name="1.7.33"></a>
## [1.7.33](https://github.com/oclif/example-multi-js/compare/v1.7.32...v1.7.33) (2018-05-01)


### Bug Fixes

* oclif v1.7.36 ([e717fc1](https://github.com/oclif/example-multi-js/commit/e717fc1))

<a name="1.7.32"></a>
## [1.7.32](https://github.com/oclif/example-multi-js/compare/v1.7.31...v1.7.32) (2018-04-21)


### Bug Fixes

* oclif v1.7.35 ([d78bf53](https://github.com/oclif/example-multi-js/commit/d78bf53))

<a name="1.7.31"></a>
## [1.7.31](https://github.com/oclif/example-multi-js/compare/v1.7.30...v1.7.31) (2018-04-20)


### Bug Fixes

* oclif v1.7.34 ([28bc965](https://github.com/oclif/example-multi-js/commit/28bc965))

<a name="1.7.30"></a>
## [1.7.30](https://github.com/oclif/example-multi-js/compare/v1.7.29...v1.7.30) (2018-04-20)


### Bug Fixes

* oclif v1.7.33 ([a9c7ef0](https://github.com/oclif/example-multi-js/commit/a9c7ef0))

<a name="1.7.29"></a>
## [1.7.29](https://github.com/oclif/example-multi-js/compare/v1.7.28...v1.7.29) (2018-04-18)


### Bug Fixes

* oclif v1.7.32 ([ce4e273](https://github.com/oclif/example-multi-js/commit/ce4e273)), closes [#108](https://github.com/oclif/example-multi-js/issues/108)

<a name="1.7.28"></a>
## [1.7.28](https://github.com/oclif/example-multi-js/compare/v1.7.27...v1.7.28) (2018-04-17)


### Bug Fixes

* oclif v1.7.31 ([7b449af](https://github.com/oclif/example-multi-js/commit/7b449af))

<a name="1.7.27"></a>
## [1.7.27](https://github.com/oclif/example-multi-js/compare/v1.7.26...v1.7.27) (2018-04-10)


### Bug Fixes

* oclif v1.7.30 ([5f644e9](https://github.com/oclif/example-multi-js/commit/5f644e9))

<a name="1.7.26"></a>
## [1.7.26](https://github.com/oclif/example-multi-js/compare/v1.7.25...v1.7.26) (2018-04-10)


### Bug Fixes

* oclif v1.7.29 ([1d1bf3c](https://github.com/oclif/example-multi-js/commit/1d1bf3c))

<a name="1.7.25"></a>
## [1.7.25](https://github.com/oclif/example-multi-js/compare/v1.7.24...v1.7.25) (2018-04-09)


### Bug Fixes

* oclif v1.7.28 ([33671a8](https://github.com/oclif/example-multi-js/commit/33671a8))

<a name="1.7.24"></a>
## [1.7.24](https://github.com/oclif/example-multi-js/compare/v1.7.23...v1.7.24) (2018-04-09)


### Bug Fixes

* oclif v1.7.27 ([845ec2f](https://github.com/oclif/example-multi-js/commit/845ec2f))

<a name="1.7.23"></a>
## [1.7.23](https://github.com/oclif/example-multi-js/compare/v1.7.22...v1.7.23) (2018-04-09)


### Bug Fixes

* oclif v1.7.26 ([daed084](https://github.com/oclif/example-multi-js/commit/daed084))

<a name="1.7.22"></a>
## [1.7.22](https://github.com/oclif/example-multi-js/compare/v1.7.21...v1.7.22) (2018-04-09)


### Bug Fixes

* oclif v1.7.25 ([f5417e9](https://github.com/oclif/example-multi-js/commit/f5417e9))

<a name="1.7.21"></a>
## [1.7.21](https://github.com/oclif/example-multi-js/compare/v1.7.20...v1.7.21) (2018-04-08)


### Bug Fixes

* oclif v1.7.24 ([43d8780](https://github.com/oclif/example-multi-js/commit/43d8780))

<a name="1.7.20"></a>
## [1.7.20](https://github.com/oclif/example-multi-js/compare/v1.7.19...v1.7.20) (2018-04-08)


### Bug Fixes

* oclif v1.7.23 ([70c163e](https://github.com/oclif/example-multi-js/commit/70c163e)), closes [#96](https://github.com/oclif/example-multi-js/issues/96)

<a name="1.7.19"></a>
## [1.7.19](https://github.com/oclif/example-multi-js/compare/v1.7.18...v1.7.19) (2018-04-08)


### Bug Fixes

* oclif v1.7.23 ([6276c87](https://github.com/oclif/example-multi-js/commit/6276c87)), closes [#96](https://github.com/oclif/example-multi-js/issues/96)

<a name="1.7.18"></a>
## [1.7.18](https://github.com/oclif/example-multi-js/compare/v1.7.17...v1.7.18) (2018-04-08)


### Bug Fixes

* oclif v1.7.21 ([14c6fb9](https://github.com/oclif/example-multi-js/commit/14c6fb9))

<a name="1.7.17"></a>
## [1.7.17](https://github.com/oclif/example-multi-js/compare/v1.7.16...v1.7.17) (2018-04-08)


### Bug Fixes

* oclif v1.7.20 ([714fc18](https://github.com/oclif/example-multi-js/commit/714fc18))

<a name="1.7.16"></a>
## [1.7.16](https://github.com/oclif/example-multi-js/compare/v1.7.15...v1.7.16) (2018-04-07)


### Bug Fixes

* oclif v1.7.19 ([7d389c9](https://github.com/oclif/example-multi-js/commit/7d389c9))

<a name="1.7.15"></a>
## [1.7.15](https://github.com/oclif/example-multi-js/compare/v1.7.14...v1.7.15) (2018-04-07)


### Bug Fixes

* oclif v1.7.18 ([ed6d310](https://github.com/oclif/example-multi-js/commit/ed6d310))

<a name="1.7.14"></a>
## [1.7.14](https://github.com/oclif/example-multi-js/compare/v1.7.13...v1.7.14) (2018-04-06)


### Bug Fixes

* oclif v1.7.17 ([3384105](https://github.com/oclif/example-multi-js/commit/3384105))

<a name="1.7.13"></a>
## [1.7.13](https://github.com/oclif/example-multi-js/compare/v1.7.12...v1.7.13) (2018-04-06)


### Bug Fixes

* oclif v1.7.16 ([08dffa4](https://github.com/oclif/example-multi-js/commit/08dffa4))

<a name="1.7.12"></a>
## [1.7.12](https://github.com/oclif/example-multi-js/compare/v1.7.11...v1.7.12) (2018-04-06)


### Bug Fixes

* oclif v1.7.15 ([c6d8c9f](https://github.com/oclif/example-multi-js/commit/c6d8c9f))

<a name="1.7.11"></a>
## [1.7.11](https://github.com/oclif/example-multi-js/compare/v1.7.10...v1.7.11) (2018-04-05)


### Bug Fixes

* oclif v1.7.14 ([2ea9326](https://github.com/oclif/example-multi-js/commit/2ea9326))

<a name="1.7.10"></a>
## [1.7.10](https://github.com/oclif/example-multi-js/compare/v1.7.9...v1.7.10) (2018-04-04)


### Bug Fixes

* oclif v1.7.12 ([6ae27cf](https://github.com/oclif/example-multi-js/commit/6ae27cf))

<a name="1.7.9"></a>
## [1.7.9](https://github.com/oclif/example-multi-js/compare/v1.7.8...v1.7.9) (2018-04-02)


### Bug Fixes

* oclif v1.7.11 ([376f5cd](https://github.com/oclif/example-multi-js/commit/376f5cd)), closes [#94](https://github.com/oclif/example-multi-js/issues/94)

<a name="1.7.8"></a>
## [1.7.8](https://github.com/oclif/example-multi-js/compare/v1.7.7...v1.7.8) (2018-03-28)


### Bug Fixes

* oclif v1.7.10 ([e7d44fa](https://github.com/oclif/example-multi-js/commit/e7d44fa)), closes [#87](https://github.com/oclif/example-multi-js/issues/87)

<a name="1.7.7"></a>
## [1.7.7](https://github.com/oclif/example-multi-js/compare/v1.7.6...v1.7.7) (2018-03-25)


### Bug Fixes

* oclif v1.7.7 ([36ff4d3](https://github.com/oclif/example-multi-js/commit/36ff4d3))

<a name="1.7.6"></a>
## [1.7.6](https://github.com/oclif/example-multi-js/compare/v1.7.5...v1.7.6) (2018-03-24)


### Bug Fixes

* oclif v1.7.6 ([e00f4a8](https://github.com/oclif/example-multi-js/commit/e00f4a8))

<a name="1.7.5"></a>
## [1.7.5](https://github.com/oclif/example-multi-js/compare/v1.7.4...v1.7.5) (2018-03-24)


### Bug Fixes

* oclif v1.7.5 ([05eebcb](https://github.com/oclif/example-multi-js/commit/05eebcb))

<a name="1.7.4"></a>
## [1.7.4](https://github.com/oclif/example-multi-js/compare/v1.7.3...v1.7.4) (2018-03-24)


### Bug Fixes

* oclif v1.7.4 ([76017a3](https://github.com/oclif/example-multi-js/commit/76017a3))

<a name="1.7.3"></a>
## [1.7.3](https://github.com/oclif/example-multi-js/compare/v1.7.2...v1.7.3) (2018-03-24)


### Bug Fixes

* oclif v1.7.3 ([cbaf7d8](https://github.com/oclif/example-multi-js/commit/cbaf7d8))

<a name="1.7.2"></a>
## [1.7.2](https://github.com/oclif/example-multi-js/compare/v1.7.1...v1.7.2) (2018-03-24)


### Bug Fixes

* oclif v1.7.2 ([c7e4b62](https://github.com/oclif/example-multi-js/commit/c7e4b62))

<a name="1.7.1"></a>
## [1.7.1](https://github.com/oclif/example-multi-js/compare/f20de5d243efa7f30d047de8afa49ef585217f52...v1.7.1) (2018-03-24)


### Bug Fixes

* oclif v1.7.1 ([c635266](https://github.com/oclif/example-multi-js/commit/c635266)), closes [#83](https://github.com/oclif/example-multi-js/issues/83)

<a name="1.7.0"></a>
# [1.7.0](https://github.com/oclif/example-multi-js/compare/9fa2dd38ea7dc79466254980b754fc2027a71c54...v1.7.0) (2018-03-24)


### Features

* oclif v1.7.0 ([f20de5d](https://github.com/oclif/example-multi-js/commit/f20de5d)), closes [oclif/oclif#69](https://github.com/oclif/oclif/issues/69)

<a name="1.6.0"></a>
# [1.6.0](https://github.com/oclif/example-multi-js/compare/2b53bbe20371e38238b6e6562fbe9bd226c02d2e...v1.6.0) (2018-03-24)


### Features

* oclif v1.6.0 ([9fa2dd3](https://github.com/oclif/example-multi-js/commit/9fa2dd3)), closes [oclif/oclif#70](https://github.com/oclif/oclif/issues/70)

<a name="1.5.8"></a>
## [1.5.8](https://github.com/oclif/example-multi-js/compare/cd06128351fb27c6afb3fbc95005784b86bd7dbd...v1.5.8) (2018-03-24)


### Bug Fixes

* oclif v1.5.8 ([2b53bbe](https://github.com/oclif/example-multi-js/commit/2b53bbe)), closes [#78](https://github.com/oclif/example-multi-js/issues/78)

<a name="1.5.7"></a>
## [1.5.7](https://github.com/oclif/example-multi-js/compare/f54414c261e8052aecfa600dcf30f1f30f70d009...v1.5.7) (2018-03-24)


### Bug Fixes

* oclif v1.5.7 ([cd06128](https://github.com/oclif/example-multi-js/commit/cd06128))

<a name="1.5.6"></a>
## [1.5.6](https://github.com/oclif/example-multi-js/compare/df2caabaf36518bcb3f7547486eb845cc2d707e4...v1.5.6) (2018-03-24)


### Bug Fixes

* oclif v1.5.6 ([f54414c](https://github.com/oclif/example-multi-js/commit/f54414c))

<a name="1.5.5"></a>
## [1.5.5](https://github.com/oclif/example-multi-js/compare/3398b413cf64ac9c5447bf207c7343cb7a368d8f...v1.5.5) (2018-03-24)


### Bug Fixes

* oclif v1.5.5 ([df2caab](https://github.com/oclif/example-multi-js/commit/df2caab))

<a name="1.5.4"></a>
## [1.5.4](https://github.com/oclif/example-multi-js/compare/1d7392f38fa906415f03c84ab95f052472513419...v1.5.4) (2018-03-24)


### Bug Fixes

* oclif v1.5.4 ([3398b41](https://github.com/oclif/example-multi-js/commit/3398b41))

<a name="1.5.3"></a>
## [1.5.3](https://github.com/oclif/example-multi-js/compare/d76dd079892d531730476ec71a950c6936109af9...v1.5.3) (2018-03-24)


### Bug Fixes

* oclif v1.5.3 ([1d7392f](https://github.com/oclif/example-multi-js/commit/1d7392f))

<a name="1.5.2"></a>
## [1.5.2](https://github.com/oclif/example-multi-js/compare/7ffe888e13b244d6273bbc31d43a65001c4a8282...v1.5.2) (2018-03-23)


### Bug Fixes

* oclif v1.5.2 ([d76dd07](https://github.com/oclif/example-multi-js/commit/d76dd07))

<a name="1.5.1"></a>
## [1.5.1](https://github.com/oclif/example-multi-js/compare/9d453fead82c1346d6067ef75eb12394834bc16a...v1.5.1) (2018-03-23)


### Bug Fixes

* oclif v1.5.1 ([7ffe888](https://github.com/oclif/example-multi-js/commit/7ffe888))

<a name="1.5.0"></a>
# [1.5.0](https://github.com/oclif/example-multi-js/compare/5102e0cb5f5f23982ba995be5387e57ca3a2c5b4...v1.5.0) (2018-03-23)


### Features

* oclif v1.5.0 ([9d453fe](https://github.com/oclif/example-multi-js/commit/9d453fe)), closes [#77](https://github.com/oclif/example-multi-js/issues/77)

<a name="1.4.9"></a>
## [1.4.9](https://github.com/oclif/example-multi-js/compare/b6e8ceab2a93677ea08081b909a01941c5c8cfc5...v1.4.9) (2018-03-23)


### Bug Fixes

* oclif v1.4.12 ([5102e0c](https://github.com/oclif/example-multi-js/commit/5102e0c))

<a name="1.4.8"></a>
## [1.4.8](https://github.com/oclif/example-multi-js/compare/be1ade8477ce2e410b17d32db5fe35ce1fd80c51...v1.4.8) (2018-03-23)


### Bug Fixes

* oclif v1.4.11 ([b6e8cea](https://github.com/oclif/example-multi-js/commit/b6e8cea))

<a name="1.4.7"></a>
## [1.4.7](https://github.com/oclif/example-multi-js/compare/72b569c1e55d9f537db48d22c9158b1f9829d445...v1.4.7) (2018-03-22)


### Bug Fixes

* oclif v1.4.10 ([be1ade8](https://github.com/oclif/example-multi-js/commit/be1ade8))

<a name="1.4.6"></a>
## [1.4.6](https://github.com/oclif/example-multi-js/compare/249c0e55c6c4165dac20be91a286bea725267cbb...v1.4.6) (2018-03-22)


### Bug Fixes

* oclif v1.4.9 ([72b569c](https://github.com/oclif/example-multi-js/commit/72b569c)), closes [#76](https://github.com/oclif/example-multi-js/issues/76)

<a name="1.4.5"></a>
## [1.4.5](https://github.com/oclif/example-multi-js/compare/3385e75243844a050a7743711b26b92eced64463...v1.4.5) (2018-03-22)


### Bug Fixes

* oclif v1.4.8 ([249c0e5](https://github.com/oclif/example-multi-js/commit/249c0e5))

<a name="1.4.4"></a>
## [1.4.4](https://github.com/oclif/example-multi-js/compare/d581ffc3524500464150a8faa4354b17373904ed...v1.4.4) (2018-03-22)


### Bug Fixes

* oclif v1.4.5 ([3385e75](https://github.com/oclif/example-multi-js/commit/3385e75))

<a name="1.4.3"></a>
## [1.4.3](https://github.com/oclif/example-multi-js/compare/be72b5d51c9b4a636fcbd76dd239e78fd9882a5d...v1.4.3) (2018-03-22)


### Bug Fixes

* oclif v1.4.3 ([d581ffc](https://github.com/oclif/example-multi-js/commit/d581ffc))

<a name="1.4.2"></a>
## [1.4.2](https://github.com/oclif/example-multi-js/compare/3725d390499bdfb27bae7f5fd467ae93844e626b...v1.4.2) (2018-03-22)


### Bug Fixes

* oclif v1.4.2 ([be72b5d](https://github.com/oclif/example-multi-js/commit/be72b5d))

<a name="1.4.1"></a>
## [1.4.1](https://github.com/oclif/example-multi-js/compare/ad489bb19a0b601f1f9bfe6ce6b33153396357e6...v1.4.1) (2018-03-21)


### Bug Fixes

* oclif v1.4.1 ([3725d39](https://github.com/oclif/example-multi-js/commit/3725d39))

<a name="1.4.0"></a>
# [1.4.0](https://github.com/oclif/example-multi-js/compare/e6de322ba77c9372cef31f9c7fb4e1fe3e9ff2cb...v1.4.0) (2018-03-21)


### Features

* oclif v1.4.0 ([ad489bb](https://github.com/oclif/example-multi-js/commit/ad489bb)), closes [#63](https://github.com/oclif/example-multi-js/issues/63)

<a name="1.3.14"></a>
## [1.3.14](https://github.com/oclif/example-multi-js/compare/aec303db85082da5a9f32aeea0f7560a280b8ca4...v1.3.14) (2018-03-21)


### Bug Fixes

* oclif v1.3.14 ([e6de322](https://github.com/oclif/example-multi-js/commit/e6de322)), closes [#62](https://github.com/oclif/example-multi-js/issues/62)

<a name="1.3.13"></a>
## [1.3.13](https://github.com/oclif/example-multi-js/compare/279d3a229ae6c7b1ce194e3f31e82d9ef3b8264b...v1.3.13) (2018-03-21)


### Bug Fixes

* oclif v1.3.13 ([aec303d](https://github.com/oclif/example-multi-js/commit/aec303d)), closes [#61](https://github.com/oclif/example-multi-js/issues/61)

<a name="1.3.12"></a>
## [1.3.12](https://github.com/oclif/example-multi-js/compare/052e5bad1842e68bc972c0e29918ab71a4fb2327...v1.3.12) (2018-03-21)


### Bug Fixes

* oclif v1.3.12 ([279d3a2](https://github.com/oclif/example-multi-js/commit/279d3a2)), closes [#60](https://github.com/oclif/example-multi-js/issues/60)

<a name="1.3.11"></a>
## [1.3.11](https://github.com/oclif/example-multi-js/compare/433c6215c5b804a4db893e5eb6c5ec054ee47989...v1.3.11) (2018-03-20)


### Bug Fixes

* oclif v1.3.11 ([052e5ba](https://github.com/oclif/example-multi-js/commit/052e5ba))

<a name="1.3.10"></a>
## [1.3.10](https://github.com/oclif/example-multi-js/compare/963782ed3674951b3a26e281c3966ed28eb230c8...v1.3.10) (2018-03-15)


### Bug Fixes

* oclif v1.3.10 ([433c621](https://github.com/oclif/example-multi-js/commit/433c621)), closes [#43](https://github.com/oclif/example-multi-js/issues/43)

<a name="1.3.9"></a>
## [1.3.9](https://github.com/oclif/example-multi-js/compare/3fc947d88420251b02e871a34d9e79dca2ce10bf...v1.3.9) (2018-03-08)


### Bug Fixes

* oclif v1.3.9 ([963782e](https://github.com/oclif/example-multi-js/commit/963782e)), closes [#42](https://github.com/oclif/example-multi-js/issues/42)

<a name="1.3.8"></a>
## [1.3.8](https://github.com/oclif/example-multi-js/compare/37ef04c5c009a58cd84972565f8c8da9f9e56a1c...v1.3.8) (2018-02-28)


### Bug Fixes

* oclif v1.3.8 ([3fc947d](https://github.com/oclif/example-multi-js/commit/3fc947d))

<a name="1.3.7"></a>
## [1.3.7](https://github.com/oclif/example-multi-js/compare/dc863253371a1d8911cd91b64c275fafadac1748...v1.3.7) (2018-02-17)


### Bug Fixes

* oclif v1.3.7 ([37ef04c](https://github.com/oclif/example-multi-js/commit/37ef04c))

<a name="1.3.6"></a>
## [1.3.6](https://github.com/oclif/example-multi-js/compare/313e0add7994ac9afcf384c431bad1fa88ccd41f...v1.3.6) (2018-02-17)


### Bug Fixes

* oclif v1.3.6 ([dc86325](https://github.com/oclif/example-multi-js/commit/dc86325))

<a name="1.3.5"></a>
## [1.3.5](https://github.com/oclif/example-multi-js/compare/2928b71f3b22b7edcdaa09d1fb72a2f54cf898e0...v1.3.5) (2018-02-17)


### Bug Fixes

* oclif v1.3.5 ([313e0ad](https://github.com/oclif/example-multi-js/commit/313e0ad))

<a name="1.3.4"></a>
## [1.3.4](https://github.com/oclif/example-multi-js/compare/3ff0eb40c042ae765fc09cb96a5844ba87f20412...v1.3.4) (2018-02-15)


### Bug Fixes

* oclif v1.3.4 ([2928b71](https://github.com/oclif/example-multi-js/commit/2928b71))

<a name="1.3.3"></a>
## [1.3.3](https://github.com/oclif/example-multi-js/compare/dd04e0aa89de5cec9707b16bd1515df762fe5538...v1.3.3) (2018-02-15)


### Bug Fixes

* oclif v1.3.3 ([3ff0eb4](https://github.com/oclif/example-multi-js/commit/3ff0eb4))

<a name="1.3.2"></a>
## [1.3.2](https://github.com/oclif/example-multi-js/compare/7260b2262bbdaaa85135f14aefae70a320d79495...v1.3.2) (2018-02-15)


### Bug Fixes

* oclif v1.3.2 ([dd04e0a](https://github.com/oclif/example-multi-js/commit/dd04e0a))

<a name="1.3.1"></a>
## [1.3.1](https://github.com/oclif/example-multi-js/compare/0b2ddb5caec690a295f8040ecb75aba0fed1181b...v1.3.1) (2018-02-15)


### Bug Fixes

* oclif v1.3.1 ([7260b22](https://github.com/oclif/example-multi-js/commit/7260b22))

<a name="1.3.0"></a>
# [1.3.0](https://github.com/oclif/example-multi-js/compare/955d4b24a583bcf7f3b033627264f9fec2a4a393...v1.3.0) (2018-02-15)


### Features

* oclif v1.3.0 ([0b2ddb5](https://github.com/oclif/example-multi-js/commit/0b2ddb5))

<a name="1.2.14"></a>
## [1.2.14](https://github.com/oclif/example-multi-js/compare/18311881beccdb28d968a1715901557f29543696...v1.2.14) (2018-02-15)


### Bug Fixes

* oclif v1.2.14 ([955d4b2](https://github.com/oclif/example-multi-js/commit/955d4b2))

<a name="1.2.13"></a>
## [1.2.13](https://github.com/oclif/example-multi-js/compare/ede337f839f17a8cd1f84ba161e318946563b505...v1.2.13) (2018-02-15)


### Bug Fixes

* oclif v1.2.13 ([1831188](https://github.com/oclif/example-multi-js/commit/1831188))

<a name="1.2.12"></a>
## [1.2.12](https://github.com/oclif/example-multi-js/compare/c79025e0eb312d8338b56144aedc6303643ebeb0...v1.2.12) (2018-02-15)


### Bug Fixes

* oclif v1.2.12 ([ede337f](https://github.com/oclif/example-multi-js/commit/ede337f))

<a name="1.2.11"></a>
## [1.2.11](https://github.com/oclif/example-multi-js/compare/9e5272147250e033e295f535c50fe61c7aa7c47c...v1.2.11) (2018-02-15)


### Bug Fixes

* oclif v1.2.11 ([c79025e](https://github.com/oclif/example-multi-js/commit/c79025e))

<a name="1.2.10"></a>
## [1.2.10](https://github.com/oclif/example-multi-js/compare/1491bd80d39d011648756add1ae76cc5a9ad9292...v1.2.10) (2018-02-15)


### Bug Fixes

* oclif v1.2.10 ([9e52721](https://github.com/oclif/example-multi-js/commit/9e52721))

<a name="1.2.9"></a>
## [1.2.9](https://github.com/oclif/example-multi-js/compare/3ac32f547f6262ba0cf86618429e0c094c231329...v1.2.9) (2018-02-15)


### Bug Fixes

* oclif v1.2.9 ([1491bd8](https://github.com/oclif/example-multi-js/commit/1491bd8))

<a name="1.2.8"></a>
## [1.2.8](https://github.com/oclif/example-multi-js/compare/c56b3fe0ee39de73c2345c8f9824b30044339234...v1.2.8) (2018-02-15)


### Bug Fixes

* oclif v1.2.8 ([3ac32f5](https://github.com/oclif/example-multi-js/commit/3ac32f5))

<a name="1.2.7"></a>
## [1.2.7](https://github.com/oclif/example-multi-js/compare/f91ab4799b4e7841d519c32fec2fe1f3e5cf7bb9...v1.2.7) (2018-02-15)


### Bug Fixes

* oclif v1.2.7 ([c56b3fe](https://github.com/oclif/example-multi-js/commit/c56b3fe))

<a name="1.2.6"></a>
## [1.2.6](https://github.com/oclif/example-multi-js/compare/0fcc875a6d83b39db33e52db3bfaa2dade7d2e27...v1.2.6) (2018-02-15)


### Bug Fixes

* oclif v1.2.6 ([f91ab47](https://github.com/oclif/example-multi-js/commit/f91ab47))

<a name="1.2.5"></a>
## [1.2.5](https://github.com/oclif/example-multi-js/compare/93e0abbd3582be0d2aea2af5488c5310040c50dd...v1.2.5) (2018-02-14)


### Bug Fixes

* oclif v1.2.5 ([0fcc875](https://github.com/oclif/example-multi-js/commit/0fcc875))

<a name="1.2.4"></a>
## [1.2.4](https://github.com/oclif/example-multi-js/compare/1c5419810126c6eb0151ebb28549732ffdb092f7...v1.2.4) (2018-02-14)


### Bug Fixes

* oclif v1.2.4 ([93e0abb](https://github.com/oclif/example-multi-js/commit/93e0abb))

<a name="1.2.3"></a>
## [1.2.3](https://github.com/oclif/example-multi-js/compare/1cc4c463b91a1914cdf66d3169fffd5da4830ba2...v1.2.3) (2018-02-14)


### Bug Fixes

* oclif v1.2.3 ([1c54198](https://github.com/oclif/example-multi-js/commit/1c54198))

<a name="1.2.2"></a>
## [1.2.2](https://github.com/oclif/example-multi-js/compare/acc1255a7be8cb3b4db68430c1b7c10f180a8e1f...v1.2.2) (2018-02-14)


### Bug Fixes

* oclif v1.2.2 ([1cc4c46](https://github.com/oclif/example-multi-js/commit/1cc4c46))

<a name="1.2.1"></a>
## [1.2.1](https://github.com/oclif/example-multi-js/compare/2dc0a50f3fb43ed890eaf333f7db3a1e886083ca...v1.2.1) (2018-02-14)


### Bug Fixes

* oclif v1.2.1 ([acc1255](https://github.com/oclif/example-multi-js/commit/acc1255))

<a name="1.2.0"></a>
# [1.2.0](https://github.com/oclif/example-multi-js/compare/e2c34eeeff2872b6fb808f4667ffcf90e5646b5e...v1.2.0) (2018-02-14)


### Features

* oclif v1.2.0 ([2dc0a50](https://github.com/oclif/example-multi-js/commit/2dc0a50))

<a name="1.1.2"></a>
## [1.1.2](https://github.com/oclif/example-multi-js/compare/e6512435d56e0ba38d6424d4a4add8557c29f7ad...v1.1.2) (2018-02-14)


### Bug Fixes

* oclif v1.1.2 ([e2c34ee](https://github.com/oclif/example-multi-js/commit/e2c34ee))

<a name="1.1.1"></a>
## [1.1.1](https://github.com/oclif/example-multi-js/compare/04931ed93062dee5288051cdc9b6446616ea0f0e...v1.1.1) (2018-02-14)


### Bug Fixes

* oclif v1.1.1 ([e651243](https://github.com/oclif/example-multi-js/commit/e651243))

<a name="1.1.0"></a>
# [1.1.0](https://github.com/oclif/example-multi-js/compare/d98f294e412f406da6f9a81f259dab7e50303c9a...v1.1.0) (2018-02-13)


### Features

* oclif v1.1.0 ([04931ed](https://github.com/oclif/example-multi-js/commit/04931ed))

<a name="1.0.4"></a>
## [1.0.4](https://github.com/oclif/example-multi-js/compare/77c32c8a7a98a5d7b01784bc086d3a17580b4e40...v1.0.4) (2018-02-13)


### Bug Fixes

* oclif v1.0.6 ([d98f294](https://github.com/oclif/example-multi-js/commit/d98f294))

<a name="1.0.3"></a>
## [1.0.3](https://github.com/oclif/example-multi-js/compare/ac3d79cc11221131700a7e906377d50bcd720e19...v1.0.3) (2018-02-13)


### Bug Fixes

* oclif v1.0.5 ([77c32c8](https://github.com/oclif/example-multi-js/commit/77c32c8))

<a name="1.0.2"></a>
## [1.0.2](https://github.com/oclif/example-multi-js/compare/be1a6a5818a51376ddf674ca7c458e0d5fe71dd1...v1.0.2) (2018-02-13)


### Bug Fixes

* oclif v1.0.4 ([ac3d79c](https://github.com/oclif/example-multi-js/commit/ac3d79c))

<a name="1.0.1"></a>
## [1.0.1](https://github.com/oclif/example-multi-js/compare/v1.0.0...v1.0.1) (2018-02-13)


### Bug Fixes

* oclif v1.0.3 ([be1a6a5](https://github.com/oclif/example-multi-js/commit/be1a6a5))

<a name="0.9.20"></a>
## [0.9.20](https://github.com/oclif/example-multi-js/compare/6d0afe587e3b62e0e79bee24676ee4a00ff205d8...v0.9.20) (2018-02-13)


### Bug Fixes

* oclif v1.0.2 ([adbf339](https://github.com/oclif/example-multi-js/commit/adbf339))

<a name="0.9.19"></a>
## [0.9.19](https://github.com/anycli/example-multi-js/compare/af980a638aa7fe383ce82c10a2f385d911a4c61c...v0.9.19) (2018-02-07)


### Bug Fixes

* anycli v0.33.22 ([4019a13](https://github.com/anycli/example-multi-js/commit/4019a13))

<a name="0.9.18"></a>
## [0.9.18](https://github.com/anycli/example-multi-js/compare/9ba74e59dd7ae1fa28888a8b346f5fa68c76d0a3...v0.9.18) (2018-02-07)


### Bug Fixes

* anycli v0.33.21 ([af980a6](https://github.com/anycli/example-multi-js/commit/af980a6))

<a name="0.9.17"></a>
## [0.9.17](https://github.com/anycli/example-multi-js/compare/3a4bceb3330ea37c6f83f74b8132e42e42db009f...v0.9.17) (2018-02-07)


### Bug Fixes

* anycli v0.33.20 ([9ba74e5](https://github.com/anycli/example-multi-js/commit/9ba74e5))

<a name="0.9.16"></a>
## [0.9.16](https://github.com/anycli/example-multi-js/compare/9f22f74cffa95eebaf98633ee05e7ae2d7cdbbfd...v0.9.16) (2018-02-07)


### Bug Fixes

* anycli v0.33.19 ([3a4bceb](https://github.com/anycli/example-multi-js/commit/3a4bceb))

<a name="0.9.15"></a>
## [0.9.15](https://github.com/anycli/example-multi-js/compare/7e45c4d343683e1e90fbd6e71d7ce93bb40c9348...v0.9.15) (2018-02-07)


### Bug Fixes

* anycli v0.33.18 ([9f22f74](https://github.com/anycli/example-multi-js/commit/9f22f74))

<a name="0.9.14"></a>
## [0.9.14](https://github.com/anycli/example-multi-js/compare/51a2484fc8e9bea77fdf8819165d3a19c0e90f73...v0.9.14) (2018-02-07)


### Bug Fixes

* anycli v0.33.17 ([7e45c4d](https://github.com/anycli/example-multi-js/commit/7e45c4d))

<a name="0.9.13"></a>
## [0.9.13](https://github.com/anycli/example-multi-js/compare/b16c80e5e087d67803614a35f98884ba028942f5...v0.9.13) (2018-02-07)


### Bug Fixes

* anycli v0.33.14 ([1e04c61](https://github.com/anycli/example-multi-js/commit/1e04c61))
* anycli v0.33.15 ([30fc701](https://github.com/anycli/example-multi-js/commit/30fc701))
* anycli v0.33.16 ([51a2484](https://github.com/anycli/example-multi-js/commit/51a2484))

<a name="0.9.12"></a>
## [0.9.12](https://github.com/anycli/example-multi-js/compare/4483494e507a82b2716f35db1aa9ddb05d1cbc30...v0.9.12) (2018-02-07)


### Bug Fixes

* anycli v0.33.13 ([b16c80e](https://github.com/anycli/example-multi-js/commit/b16c80e))

<a name="0.9.11"></a>
## [0.9.11](https://github.com/anycli/example-multi-js/compare/154e57dfaef49bc8e8db0c7ebb0c056a1b5c5c9a...v0.9.11) (2018-02-06)


### Bug Fixes

* anycli v0.33.13 ([4483494](https://github.com/anycli/example-multi-js/commit/4483494))

<a name="0.9.10"></a>
## [0.9.10](https://github.com/anycli/example-multi-js/compare/552fed245a28e371646836d9ff1244841f0a0f2a...v0.9.10) (2018-02-06)


### Bug Fixes

* anycli v0.33.12 ([154e57d](https://github.com/anycli/example-multi-js/commit/154e57d))

<a name="0.9.9"></a>
## [0.9.9](https://github.com/anycli/example-multi-js/compare/71be79bc0de26697c9968eecabcdbcac241f01ac...v0.9.9) (2018-02-06)


### Bug Fixes

* anycli v0.33.11 ([552fed2](https://github.com/anycli/example-multi-js/commit/552fed2))

<a name="0.9.8"></a>
## [0.9.8](https://github.com/anycli/example-multi-js/compare/6caeff944427db20fd520970d7d30dd391134e8b...v0.9.8) (2018-02-06)


### Bug Fixes

* anycli v0.33.10 ([71be79b](https://github.com/anycli/example-multi-js/commit/71be79b))

<a name="0.9.7"></a>
## [0.9.7](https://github.com/anycli/example-multi-js/compare/647a095a2bd4c3c1ff2a663239c10923167c9c0e...v0.9.7) (2018-02-05)


### Bug Fixes

* anycli v0.33.9 ([6caeff9](https://github.com/anycli/example-multi-js/commit/6caeff9))

<a name="0.9.6"></a>
## [0.9.6](https://github.com/anycli/example-multi-js/compare/c00dd1e741705a847f04b6382ac247cf68fa1bd2...v0.9.6) (2018-02-05)


### Bug Fixes

* anycli v0.33.6 ([647a095](https://github.com/anycli/example-multi-js/commit/647a095))

<a name="0.9.5"></a>
## [0.9.5](https://github.com/anycli/example-multi-js/compare/2e7c411570fb3ce9e3925c744c1ded1d9c851c5a...v0.9.5) (2018-02-05)


### Bug Fixes

* anycli v0.33.5 ([c00dd1e](https://github.com/anycli/example-multi-js/commit/c00dd1e))

<a name="0.9.4"></a>
## [0.9.4](https://github.com/anycli/example-multi-js/compare/0226016dc47cccb6f036de053e462716d4e0c47b...v0.9.4) (2018-02-04)


### Bug Fixes

* anycli v0.33.4 ([2e7c411](https://github.com/anycli/example-multi-js/commit/2e7c411))

<a name="0.9.3"></a>
## [0.9.3](https://github.com/anycli/example-multi-js/compare/c3f5481f2ad558818cdecaf57fef7b94c121f9d8...v0.9.3) (2018-02-03)


### Bug Fixes

* anycli v0.33.3 ([0226016](https://github.com/anycli/example-multi-js/commit/0226016))

<a name="0.9.2"></a>
## [0.9.2](https://github.com/anycli/example-multi-js/compare/e3b2ace5b7bb9b717f3de453a491c86508c35e19...v0.9.2) (2018-02-02)


### Bug Fixes

* anycli v0.33.2 ([c3f5481](https://github.com/anycli/example-multi-js/commit/c3f5481))

<a name="0.9.1"></a>
## [0.9.1](https://github.com/anycli/example-multi-js/compare/b6dd8a3f86b397d7e794a9cbc3754077b6073401...v0.9.1) (2018-02-02)


### Bug Fixes

* anycli v0.33.1 ([e3b2ace](https://github.com/anycli/example-multi-js/commit/e3b2ace))

<a name="0.9.0"></a>
# [0.9.0](https://github.com/anycli/example-multi-js/compare/b068614f5f092fb6596099fdfcfb6a4e2b1e9216...v0.9.0) (2018-02-02)


### Features

* anycli v0.33.0 ([b6dd8a3](https://github.com/anycli/example-multi-js/commit/b6dd8a3))

<a name="0.8.11"></a>
## [0.8.11](https://github.com/anycli/example-multi-js/compare/05e16643aeb9451981eb04c4759e44b6c8ed7bfc...v0.8.11) (2018-02-02)


### Bug Fixes

* anycli v0.32.16 ([b068614](https://github.com/anycli/example-multi-js/commit/b068614))

<a name="0.8.10"></a>
## [0.8.10](https://github.com/anycli/example-multi-js/compare/7d5141ee1a5b027b277762361471a4ae79bba462...v0.8.10) (2018-02-02)


### Bug Fixes

* anycli v0.32.15 ([05e1664](https://github.com/anycli/example-multi-js/commit/05e1664))

<a name="0.8.9"></a>
## [0.8.9](https://github.com/anycli/example-multi-js/compare/62b39719871a2323a3a51f432a8e1f1e2d0f957f...v0.8.9) (2018-02-02)


### Bug Fixes

* anycli v0.32.14 ([7d5141e](https://github.com/anycli/example-multi-js/commit/7d5141e))

<a name="0.8.8"></a>
## [0.8.8](https://github.com/anycli/example-multi-js/compare/f78b1c6d999b630d1a0911a32fd38486f523222d...v0.8.8) (2018-02-02)


### Bug Fixes

* anycli v0.32.13 ([62b3971](https://github.com/anycli/example-multi-js/commit/62b3971))

<a name="0.8.7"></a>
## [0.8.7](https://github.com/anycli/example-multi-js/compare/0225a0d44a9f6614954a16138ea6678e08cbe7ca...v0.8.7) (2018-02-02)


### Bug Fixes

* anycli v0.32.12 ([f78b1c6](https://github.com/anycli/example-multi-js/commit/f78b1c6))

<a name="0.8.6"></a>
## [0.8.6](https://github.com/anycli/example-multi-js/compare/b2bd7403d82fe627f40e181fce44f2686c110cd9...v0.8.6) (2018-02-02)


### Bug Fixes

* anycli v0.32.10 ([3ec9997](https://github.com/anycli/example-multi-js/commit/3ec9997))
* anycli v0.32.11 ([0225a0d](https://github.com/anycli/example-multi-js/commit/0225a0d))

<a name="0.8.5"></a>
## [0.8.5](https://github.com/anycli/example-multi-js/compare/80c0147cdf5f2e54cbfc672aa99e3812b3fc3ceb...v0.8.5) (2018-02-02)


### Bug Fixes

* anycli v0.32.8 ([b2bd740](https://github.com/anycli/example-multi-js/commit/b2bd740))

<a name="0.8.4"></a>
## [0.8.4](https://github.com/anycli/example-multi-js/compare/d2ef86dfa398e4f14603055d2046a9ea584a28de...v0.8.4) (2018-02-02)


### Bug Fixes

* anycli v0.32.7 ([80c0147](https://github.com/anycli/example-multi-js/commit/80c0147))

<a name="0.8.3"></a>
## [0.8.3](https://github.com/anycli/example-multi-js/compare/a65b120fbbcc5672330cec9e52c2b3ac45616a67...v0.8.3) (2018-02-02)


### Bug Fixes

* anycli v0.32.6 ([d2ef86d](https://github.com/anycli/example-multi-js/commit/d2ef86d))

<a name="0.8.2"></a>
## [0.8.2](https://github.com/anycli/example-multi-js/compare/8bd4fe6401761eed17c806aa0a3f97bfad5f2b60...v0.8.2) (2018-02-02)


### Bug Fixes

* anycli v0.32.5 ([a65b120](https://github.com/anycli/example-multi-js/commit/a65b120))

<a name="0.8.1"></a>
## [0.8.1](https://github.com/anycli/example-multi-js/compare/632e4c7580c3b8d921275fa3f339fff7ee749305...v0.8.1) (2018-02-02)


### Bug Fixes

* anycli v0.32.2 ([c33798f](https://github.com/anycli/example-multi-js/commit/c33798f))
* anycli v0.32.3 ([6840a58](https://github.com/anycli/example-multi-js/commit/6840a58))
* anycli v0.32.4 ([8bd4fe6](https://github.com/anycli/example-multi-js/commit/8bd4fe6))

<a name="0.8.0"></a>
# [0.8.0](https://github.com/anycli/example-multi-js/compare/1cbea60e80ba754dd1b39a0986daf1b8f320f0c6...v0.8.0) (2018-02-01)


### Bug Fixes

* anycli v0.32.1 ([632e4c7](https://github.com/anycli/example-multi-js/commit/632e4c7))


### Features

* anycli v0.32.0 ([86563a5](https://github.com/anycli/example-multi-js/commit/86563a5))

<a name="0.7.1"></a>
## [0.7.1](https://github.com/anycli/example-multi-js/compare/2a6b8c42e68db0c0cf5dcc8cd637da9c41cb0922...v0.7.1) (2018-02-01)


### Bug Fixes

* anycli v0.31.1 ([1cbea60](https://github.com/anycli/example-multi-js/commit/1cbea60))

<a name="0.7.0"></a>
# [0.7.0](https://github.com/anycli/example-multi-js/compare/44c510c6ab027dda35924f0f37402e79cfa22e3c...v0.7.0) (2018-02-01)


### Features

* anycli v0.31.0 ([2a6b8c4](https://github.com/anycli/example-multi-js/commit/2a6b8c4))

<a name="0.6.4"></a>
## [0.6.4](https://github.com/anycli/example-multi-js/compare/0db306aea2a4d527eead6bef4fc5574ec32945c3...v0.6.4) (2018-02-01)


### Bug Fixes

* anycli v0.30.7 ([44c510c](https://github.com/anycli/example-multi-js/commit/44c510c))

<a name="0.6.3"></a>
## [0.6.3](https://github.com/anycli/example-multi-js/compare/7f0d3d5bf6a13571c8d6070549a2d2ed314556a1...v0.6.3) (2018-02-01)


### Bug Fixes

* anycli v0.30.6 ([0db306a](https://github.com/anycli/example-multi-js/commit/0db306a))

<a name="0.6.2"></a>
## [0.6.2](https://github.com/anycli/example-multi-js/compare/e9a3041ab2d88f8fc46e4da19bc162a895921a75...v0.6.2) (2018-02-01)


### Bug Fixes

* anycli v0.30.4 ([7f0d3d5](https://github.com/anycli/example-multi-js/commit/7f0d3d5))

<a name="0.6.1"></a>
## [0.6.1](https://github.com/anycli/example-multi-js/compare/faef955d4c8ae755b8c7dd03d638bf663a360e74...v0.6.1) (2018-02-01)


### Bug Fixes

* anycli v0.30.1 ([89f91fc](https://github.com/anycli/example-multi-js/commit/89f91fc))
* anycli v0.30.2 ([e9a3041](https://github.com/anycli/example-multi-js/commit/e9a3041))

<a name="0.6.0"></a>
# [0.6.0](https://github.com/anycli/example-multi-js/compare/dddd9ba6ad42c2fc50e9e4e9c5c3ed4d00e39896...v0.6.0) (2018-02-01)


### Features

* anycli v0.30.0 ([faef955](https://github.com/anycli/example-multi-js/commit/faef955))

<a name="0.5.0"></a>
# [0.5.0](https://github.com/anycli/example-multi-js/compare/b33783efcad167b5dba4c16eb17ca794a4c68f06...v0.5.0) (2018-02-01)


### Features

* anycli v0.29.0 ([dddd9ba](https://github.com/anycli/example-multi-js/commit/dddd9ba))

<a name="0.4.0"></a>
# [0.4.0](https://github.com/anycli/example-multi-js/compare/75ada793d05e086b8b6f91ce0d93d8f8a2067c79...v0.4.0) (2018-01-31)


### Features

* anycli v1.0.0 ([b33783e](https://github.com/anycli/example-multi-js/commit/b33783e))

<a name="0.3.0"></a>
# [0.3.0](https://github.com/anycli/example-multi-js/compare/7e6c7378466a78d8de2fb6c0d2f12e51ca9c8797...v0.3.0) (2018-01-31)


### Features

* anycli v1.0.0 ([75ada79](https://github.com/anycli/example-multi-js/commit/75ada79))

<a name="0.2.0"></a>
# [0.2.0](https://github.com/anycli/example-multi-js/compare/v0.1.11...v0.2.0) (2018-01-31)


### Features

* anycli v1.0.0 ([7e6c737](https://github.com/anycli/example-multi-js/commit/7e6c737))

<a name="0.1.11"></a>
## [0.1.11](https://github.com/dxcli/example-multi-js/compare/f999cd908343ada9766b381cf671edc7cbee3e2d...v0.1.11) (2018-01-30)


### Bug Fixes

* create-dxcli v0.28.15 ([074b088](https://github.com/dxcli/example-multi-js/commit/074b088))

<a name="0.1.10"></a>
## [0.1.10](https://github.com/dxcli/example-multi-js/compare/be716ef363e0a8102f9483eaa226f9bf0ea317e7...v0.1.10) (2018-01-30)


### Bug Fixes

* create-dxcli v0.28.14 ([f999cd9](https://github.com/dxcli/example-multi-js/commit/f999cd9))

<a name="0.1.9"></a>
## [0.1.9](https://github.com/dxcli/example-multi-js/compare/91b3f143331445523702e0b14808a48e87b46857...v0.1.9) (2018-01-30)


### Bug Fixes

* create-dxcli v0.28.13 ([be716ef](https://github.com/dxcli/example-multi-js/commit/be716ef))

<a name="0.1.8"></a>
## [0.1.8](https://github.com/dxcli/example-multi-js/compare/1e459c374d73483da632711734f425cc2db49941...v0.1.8) (2018-01-30)


### Bug Fixes

* create-dxcli v0.28.12 ([91b3f14](https://github.com/dxcli/example-multi-js/commit/91b3f14))

<a name="0.1.7"></a>
## [0.1.7](https://github.com/dxcli/example-multi-js/compare/28f37d3129a4f416b2da76e1f90a05cf82c7ebb1...v0.1.7) (2018-01-30)


### Bug Fixes

* create-dxcli v0.28.11 ([1e459c3](https://github.com/dxcli/example-multi-js/commit/1e459c3))

<a name="0.1.6"></a>
## [0.1.6](https://github.com/dxcli/example-multi-js/compare/5ae33cc0344cb78c931521add13ab1ea250fb970...v0.1.6) (2018-01-30)


### Bug Fixes

* create-dxcli v0.28.10 ([28f37d3](https://github.com/dxcli/example-multi-js/commit/28f37d3))

<a name="0.1.5"></a>
## [0.1.5](https://github.com/dxcli/example-multi-js/compare/4b24101a6059341eee11c5837a307b0e3c717a0a...v0.1.5) (2018-01-30)


### Bug Fixes

* create-dxcli v0.28.8 ([5ae33cc](https://github.com/dxcli/example-multi-js/commit/5ae33cc))

<a name="0.1.4"></a>
## [0.1.4](https://github.com/dxcli/example-multi-js/compare/f7b7aebc91f192efa59571e85fde8568e5e4f922...v0.1.4) (2018-01-30)


### Bug Fixes

* create-dxcli v0.28.7 ([4b24101](https://github.com/dxcli/example-multi-js/commit/4b24101))

<a name="0.1.3"></a>
## [0.1.3](https://github.com/dxcli/example-multi-js/compare/0b75ada1f17a7c5a196faf407c36fc7cb5a25ee2...v0.1.3) (2018-01-30)


### Bug Fixes

* create-dxcli v0.28.6 ([f7b7aeb](https://github.com/dxcli/example-multi-js/commit/f7b7aeb))

<a name="0.1.2"></a>
## [0.1.2](https://github.com/dxcli/example-multi-js/compare/249b6b657e57d07e2e1ebc6da52726f0f8dba9f3...v0.1.2) (2018-01-29)


### Bug Fixes

* create-dxcli v0.28.2 ([ae101f5](https://github.com/dxcli/example-multi-js/commit/ae101f5))
* create-dxcli v0.28.3 ([03957e9](https://github.com/dxcli/example-multi-js/commit/03957e9))
* create-dxcli v0.28.4 ([d69753d](https://github.com/dxcli/example-multi-js/commit/d69753d))
* create-dxcli v0.28.5 ([0b75ada](https://github.com/dxcli/example-multi-js/commit/0b75ada))

<a name="0.1.1"></a>
## [0.1.1](https://github.com/dxcli/example-multi-js/compare/7480bcbbef2d8f222bacef7a5d7f8b3239dee21f...v0.1.1) (2018-01-29)


### Bug Fixes

* create-dxcli v0.28.1 ([249b6b6](https://github.com/dxcli/example-multi-js/commit/249b6b6))

<a name="0.1.0"></a>
# [0.1.0](https://github.com/dxcli/example-multi-js/compare/38684e2d51812e65d749c3e9a5edfea66fe07620...v0.1.0) (2018-01-28)


### Features

* create-dxcli v0.28.0 ([7480bcb](https://github.com/dxcli/example-multi-js/commit/7480bcb))

<a name="0.0.13"></a>
## [0.0.13](https://github.com/dxcli/example-multi-js/compare/b404b34ae4a8f1243f6caad0d817e3c606439fd6...v0.0.13) (2018-01-28)


### Bug Fixes

* create-dxcli 0.26.11 ([38684e2](https://github.com/dxcli/example-multi-js/commit/38684e2))

<a name="0.0.12"></a>
## [0.0.12](https://github.com/dxcli/example-multi-js/compare/866072a87afcd6a7c029eb5e1d48e0ccc204512c...v0.0.12) (2018-01-28)


### Bug Fixes

* create-dxcli 0.26.10 ([b404b34](https://github.com/dxcli/example-multi-js/commit/b404b34))

<a name="0.0.11"></a>
## [0.0.11](https://github.com/dxcli/example-multi-js/compare/23140be72f1de690d5442bf6b4f1226c3d7ac3ae...v0.0.11) (2018-01-28)


### Bug Fixes

* create-dxcli 0.26.9 ([866072a](https://github.com/dxcli/example-multi-js/commit/866072a))

<a name="0.0.10"></a>
## [0.0.10](https://github.com/dxcli/example-multi-cli-javascript/compare/b99986296dd43ddad27616e21cc61c521536c0e1...v0.0.10) (2018-01-28)


### Bug Fixes

* create-dxcli 0.26.3 ([6de42b7](https://github.com/dxcli/example-multi-cli-javascript/commit/6de42b7))

<a name="0.0.9"></a>
## [0.0.9](https://github.com/dxcli/example-multi-cli-javascript/compare/9d97e478982d9dabcfcf78e1c871676d7eeebac3...v0.0.9) (2018-01-28)


### Bug Fixes

* create-dxcli 0.26.2 ([b999862](https://github.com/dxcli/example-multi-cli-javascript/commit/b999862))

<a name="0.0.8"></a>
## [0.0.8](https://github.com/dxcli/example-multi-cli-javascript/compare/105f9fdd986f6f494ea971e47bf0420f664f08f4...v0.0.8) (2018-01-28)


### Bug Fixes

* create-dxcli 0.26.1 ([9d97e47](https://github.com/dxcli/example-multi-cli-javascript/commit/9d97e47))

<a name="0.0.7"></a>
## [0.0.7](https://github.com/dxcli/example-multi-cli-javascript/compare/e1f00e793519182eebceeb128b4038fd07445cd1...v0.0.7) (2018-01-27)


### Bug Fixes

* create-dxcli 0.26.0 ([105f9fd](https://github.com/dxcli/example-multi-cli-javascript/commit/105f9fd))

<a name="0.0.6"></a>
## [0.0.6](https://github.com/dxcli/example-multi-cli-javascript/compare/92685fcc9300150d58e2f0eed0982e5c5612b233...v0.0.6) (2018-01-27)


### Bug Fixes

* create-dxcli 0.26.0 ([e1f00e7](https://github.com/dxcli/example-multi-cli-javascript/commit/e1f00e7))

<a name="0.0.5"></a>
## [0.0.5](https://github.com/dxcli/example-multi-cli-javascript/compare/ff4afbb6803f2cc3a879e17991b1b5e298aa2713...v0.0.5) (2018-01-27)


### Bug Fixes

* create-dxcli 0.25.2 ([92685fc](https://github.com/dxcli/example-multi-cli-javascript/commit/92685fc))

<a name="0.0.4"></a>
## [0.0.4](https://github.com/dxcli/example-multi-cli-javascript/compare/4e1234b1baa7916d4b8a557301a08a45346cf486...v0.0.4) (2018-01-27)


### Bug Fixes

* create-dxcli 0.25.1 ([ff4afbb](https://github.com/dxcli/example-multi-cli-javascript/commit/ff4afbb))

<a name="0.0.3"></a>
## [0.0.3](https://github.com/dxcli/example-multi-cli-javascript/compare/v0.0.2...v0.0.3) (2018-01-27)


### Bug Fixes

* create-dxcli 0.25.0 ([4e1234b](https://github.com/dxcli/example-multi-cli-javascript/commit/4e1234b))

<a name="0.0.1"></a>
## [0.0.1](https://github.com/dxcli/example-multi-cli-javascript/compare/v0.0.0...v0.0.1) (2018-01-26)


### Bug Fixes

* ran generator ([ac7ab9e](https://github.com/dxcli/example-multi-cli-javascript/commit/ac7ab9e))
